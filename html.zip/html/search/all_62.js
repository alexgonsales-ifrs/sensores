var searchData=
[
  ['botoes_2ec',['botoes.c',['../botoes_8c.html',1,'']]],
  ['botoes_2eh',['botoes.h',['../botoes_8h.html',1,'']]],
  ['bt_5fdown',['BT_DOWN',['../botoes_8h.html#a8ab1dd7cd9fe847c7d4b99e32eef36ff',1,'botoes.h']]],
  ['bt_5fdown_5ftris',['BT_DOWN_TRIS',['../botoes_8h.html#af0e8de87af60b4b22e0ea0b66882e1ca',1,'botoes.h']]],
  ['bt_5fstart_5fsel',['BT_START_SEL',['../botoes_8h.html#a8209d7ddfd7db077349a29ca8456f6ab',1,'botoes.h']]],
  ['bt_5fstart_5fsel_5ftris',['BT_START_SEL_TRIS',['../botoes_8h.html#a9fa126c06a8e460b22f53bd75ca34218',1,'botoes.h']]],
  ['bt_5fstop_5fesc',['BT_STOP_ESC',['../botoes_8h.html#a5e4264e5f221e449fe8159b3420044e1',1,'botoes.h']]],
  ['bt_5fstop_5fesc_5ftris',['BT_STOP_ESC_TRIS',['../botoes_8h.html#ad796bbf8b93664d020483284a3880d8b',1,'botoes.h']]],
  ['bt_5fup',['BT_UP',['../botoes_8h.html#a0cbea531ed2900ee3c01d49b98458ff3',1,'botoes.h']]],
  ['bt_5fup_5ftris',['BT_UP_TRIS',['../botoes_8h.html#af9e8732a2cfe1e3bc0a85e62ee0261b0',1,'botoes.h']]],
  ['btns_5finit',['btns_init',['../botoes_8c.html#a6753ccd7bf04d623b0753401381f58c6',1,'btns_init(void):&#160;botoes.c'],['../botoes_8h.html#a6753ccd7bf04d623b0753401381f58c6',1,'btns_init(void):&#160;botoes.c']]],
  ['btns_5ftesta',['btns_testa',['../botoes_8c.html#ad4701ffbc00f9c34c9aaef09a9ad53e9',1,'btns_testa(void):&#160;botoes.c'],['../botoes_8h.html#ad4701ffbc00f9c34c9aaef09a9ad53e9',1,'btns_testa(void):&#160;botoes.c']]]
];
