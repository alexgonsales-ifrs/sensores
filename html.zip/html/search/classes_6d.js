var searchData=
[
  ['menu_5famostra',['menu_amostra',['../structmenu__amostra.html',1,'']]],
  ['menu_5fsensores',['menu_sensores',['../structmenu__sensores.html',1,'']]]
];
