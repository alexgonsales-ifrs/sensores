var searchData=
[
  ['qtd_5fmax_5famostras',['QTD_MAX_AMOSTRAS',['../eeprom_8h.html#a205e1f3d7ffbb4cac713723875d346a4',1,'eeprom.h']]],
  ['quant_5fsensores_2eh',['quant_sensores.h',['../quant__sensores_8h.html',1,'']]],
  ['quant_5fsensores_5fdefault',['QUANT_SENSORES_DEFAULT',['../global_8h.html#a10e7e004ffeaac152b2ca5651c355ca8',1,'global.h']]]
];
