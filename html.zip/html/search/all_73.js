var searchData=
[
  ['s_5fpos',['S_pos',['../structS__pos.html',1,'']]],
  ['str_5fquant_5fsensores',['str_quant_sensores',['../structmenu__sensores.html#ade8333a14e639c32c6aa851a99b5ceee',1,'menu_sensores']]],
  ['str_5ftempo_5famostra',['str_tempo_amostra',['../structmenu__amostra.html#a3fb9d758e2911020b4571ac78f4ee99d',1,'menu_amostra']]]
];
