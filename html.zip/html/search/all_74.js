var searchData=
[
  ['tam_5fmenu_5finicial',['TAM_MENU_INICIAL',['../menu_8h.html#a3a1fd1d8ef99a181c9eb18518801be91',1,'menu.h']]],
  ['tam_5fmenu_5fquant_5fsensores',['TAM_MENU_QUANT_SENSORES',['../menu_8h.html#af2c7b5b1813262aa2347c0acfef554eb',1,'menu.h']]],
  ['tempo_5f10_5fminutos',['TEMPO_10_MINUTOS',['../global_8h.html#a10ec51b6d14cf7509baf653a55bf48c1',1,'global.h']]],
  ['tempo_5f10_5fsegundos',['TEMPO_10_SEGUNDOS',['../global_8h.html#ad4e13b05c1e8d2b03ea4a9ab7dda3efd',1,'global.h']]],
  ['tempo_5f1_5fhora',['TEMPO_1_HORA',['../global_8h.html#a39fa7d492a6ef7ee0c45c57b51a730b3',1,'global.h']]],
  ['tempo_5f1_5fminuto',['TEMPO_1_MINUTO',['../global_8h.html#a9c7fcd3bb85f5ac9d6e336916093bcd1',1,'global.h']]],
  ['tempo_5f1_5fsegundo',['TEMPO_1_SEGUNDO',['../global_8h.html#ace4deec54eb8e8875f957e9c121a6576',1,'global.h']]],
  ['tempo_5f30_5fminutos',['TEMPO_30_MINUTOS',['../global_8h.html#ad9ff97469457c2c864b5fefafe95d228',1,'global.h']]],
  ['tempo_5f30_5fsegundos',['TEMPO_30_SEGUNDOS',['../global_8h.html#ac944f1da95d192019bda5a0d0a6f0d29',1,'global.h']]],
  ['tempo_5famostra_2eh',['tempo_amostra.h',['../tempo__amostra_8h.html',1,'']]],
  ['tempo_5famostra_5fdefault',['TEMPO_AMOSTRA_DEFAULT',['../global_8h.html#a268d68fcac9c8cc5c79002a09ec73720',1,'global.h']]],
  ['timer_2ec',['timer.c',['../timer_8c.html',1,'']]],
  ['timer_2eh',['timer.h',['../timer_8h.html',1,'']]],
  ['timer0_5finit',['timer0_init',['../timer_8c.html#a99ccbea44caa7d91c17782c602f956ef',1,'timer0_init(void):&#160;timer.c'],['../timer_8h.html#a99ccbea44caa7d91c17782c602f956ef',1,'timer0_init(void):&#160;timer.c']]]
];
