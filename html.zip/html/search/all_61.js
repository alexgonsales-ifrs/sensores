var searchData=
[
  ['adcon_2ec',['adcon.c',['../adcon_8c.html',1,'']]],
  ['adcon_2eh',['adcon.h',['../adcon_8h.html',1,'']]],
  ['adcon_5fcaptura_5fgrava',['adcon_captura_grava',['../adcon_8c.html#a349b033b81d4f955917b6c553360a015',1,'adcon_captura_grava(void):&#160;adcon.c'],['../adcon_8h.html#a349b033b81d4f955917b6c553360a015',1,'adcon_captura_grava(void):&#160;adcon.c']]],
  ['adcon_5finit',['adcon_init',['../adcon_8c.html#a4032f7c02fdf7fb92b8ff8215ce2779e',1,'adcon_init(void):&#160;adcon.c'],['../adcon_8h.html#a4032f7c02fdf7fb92b8ff8215ce2779e',1,'adcon_init(void):&#160;adcon.c']]],
  ['adcon_5fler_5fcanal',['adcon_ler_canal',['../adcon_8c.html#ac9fc26666bbaebecf572dd244fee3096',1,'adcon_ler_canal(uint8_t cnl):&#160;adcon.c'],['../adcon_8h.html#ac9fc26666bbaebecf572dd244fee3096',1,'adcon_ler_canal(uint8_t cnl):&#160;adcon.c']]],
  ['adcon_5fmedia',['ADCON_MEDIA',['../adcon_8h.html#a83589e70029f2f0697d84ef5b9e22287',1,'adcon.h']]],
  ['adcon_5fmostra',['adcon_mostra',['../adcon_8c.html#a6141934e8744640f92742bc815aa1ebc',1,'adcon_mostra(uint16_t t_int, uint8_t i):&#160;adcon.c'],['../adcon_8h.html#a6141934e8744640f92742bc815aa1ebc',1,'adcon_mostra(uint16_t t_int, uint8_t i):&#160;adcon.c']]]
];
