var searchData=
[
  ['quant_5fsensores_2eh',['quant_sensores.h',['../quant__sensores_8h.html',1,'']]]
];
