var searchData=
[
  ['end_5famostra_5fmax',['END_AMOSTRA_MAX',['../eeprom_8h.html#aba28e32e2f929d238a6a7319bb842851',1,'eeprom.h']]],
  ['end_5famostra_5fmin',['END_AMOSTRA_MIN',['../eeprom_8h.html#a4f19cfab32278de03dc928bd8868ee29',1,'eeprom.h']]],
  ['end_5fchave_5finicializacao',['END_CHAVE_INICIALIZACAO',['../eeprom_8h.html#a993cfb211546570fc0692cfc9388da6a',1,'eeprom.h']]],
  ['end_5finicio_5famostras',['END_INICIO_AMOSTRAS',['../eeprom_8h.html#ac10e09fdc1cbe2b3d5245f6342dc8457',1,'eeprom.h']]],
  ['end_5fqtde_5fsensores',['END_QTDE_SENSORES',['../eeprom_8h.html#a729566b60620b1d60018ec9432d8c324',1,'eeprom.h']]],
  ['end_5fqtde_5fvalores',['END_QTDE_VALORES',['../eeprom_8h.html#a3813739a581868a560e2d899683bc8ca',1,'eeprom.h']]],
  ['end_5ftx_5famostra',['END_TX_AMOSTRA',['../eeprom_8h.html#ae88f4e1953e948186650b6c00128fa7e',1,'eeprom.h']]]
];
