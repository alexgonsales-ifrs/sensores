var searchData=
[
  ['_5flm35_5f',['_LM35_',['../versao_8h.html#a08d22016d3a275c1af21282ba483f09f',1,'versao.h']]],
  ['_5fmodulo_5fnovo_5f',['_MODULO_NOVO_',['../versao_8h.html#aedc1271189339aab58abf35a58124301',1,'versao.h']]],
  ['_5fxtal_5ffreq',['_XTAL_FREQ',['../xtal_8h.html#a024148e99a7143db044a48216664d03d',1,'xtal.h']]]
];
