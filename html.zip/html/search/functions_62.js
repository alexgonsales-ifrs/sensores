var searchData=
[
  ['btns_5finit',['btns_init',['../botoes_8c.html#a6753ccd7bf04d623b0753401381f58c6',1,'btns_init(void):&#160;botoes.c'],['../botoes_8h.html#a6753ccd7bf04d623b0753401381f58c6',1,'btns_init(void):&#160;botoes.c']]],
  ['btns_5ftesta',['btns_testa',['../botoes_8c.html#ad4701ffbc00f9c34c9aaef09a9ad53e9',1,'btns_testa(void):&#160;botoes.c'],['../botoes_8h.html#ad4701ffbc00f9c34c9aaef09a9ad53e9',1,'btns_testa(void):&#160;botoes.c']]]
];
