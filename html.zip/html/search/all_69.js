var searchData=
[
  ['i_5fquant_5fsensores',['i_quant_sensores',['../structmenu__sensores.html#ac78833ccf2a23ed35c02345d236d8210',1,'menu_sensores']]],
  ['inv_5fn',['INV_N',['../mq6_8h.html#a5f61be8d57e470d7df67d4ef6c56bcb7',1,'mq6.h']]]
];
