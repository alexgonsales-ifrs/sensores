var searchData=
[
  ['est_5fcaptura_5fe_5fgrava',['EST_CAPTURA_E_GRAVA',['../estados_8h.html#a5a0141a5c34ffde5fa1b0c5a93956c30a0e61c5a8cf872e9030db50ac521c457e',1,'estados.h']]],
  ['est_5fcaptura_5fe_5fmostra',['EST_CAPTURA_E_MOSTRA',['../estados_8h.html#a5a0141a5c34ffde5fa1b0c5a93956c30a48e252959b986486a21a164d626bcb15',1,'estados.h']]],
  ['est_5finicio',['EST_INICIO',['../estados_8h.html#a5a0141a5c34ffde5fa1b0c5a93956c30a402b58fc7dd38c6fcedd7d16f23fdf7f',1,'estados.h']]],
  ['est_5flimpar',['EST_LIMPAR',['../estados_8h.html#a5a0141a5c34ffde5fa1b0c5a93956c30a85af45c27f2fd8b1c85e0b34b7ac57a5',1,'estados.h']]],
  ['est_5fmenu_5fconf_5fquant_5fsensores',['EST_MENU_CONF_QUANT_SENSORES',['../estados_8h.html#a5a0141a5c34ffde5fa1b0c5a93956c30a8010a998a6fafbf1d57180406aade691',1,'estados.h']]],
  ['est_5fmenu_5fconf_5ftempo_5famostra',['EST_MENU_CONF_TEMPO_AMOSTRA',['../estados_8h.html#a5a0141a5c34ffde5fa1b0c5a93956c30aca1e72002e4f335f6339da08975d7613',1,'estados.h']]],
  ['est_5fmenu_5fprincipal',['EST_MENU_PRINCIPAL',['../estados_8h.html#a5a0141a5c34ffde5fa1b0c5a93956c30a7afd9e889caf8b44945ceb05ad2a99b1',1,'estados.h']]],
  ['est_5fmostra_5fmax_5fmin',['EST_MOSTRA_MAX_MIN',['../estados_8h.html#a5a0141a5c34ffde5fa1b0c5a93956c30a94c424d9be6e0c452a85e0568847269f',1,'estados.h']]],
  ['est_5fmostra_5ftodos',['EST_MOSTRA_TODOS',['../estados_8h.html#a5a0141a5c34ffde5fa1b0c5a93956c30a4c45e5204899d66df9bebc046539bb4d',1,'estados.h']]]
];
