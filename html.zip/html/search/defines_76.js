var searchData=
[
  ['valor_5fchave',['VALOR_CHAVE',['../global_8h.html#ad6bf19f0e873b6f9b93bc44c5efdb0b1',1,'global.h']]],
  ['valor_5fmaximo_5famostra',['VALOR_MAXIMO_AMOSTRA',['../global_8h.html#ae5b3f157e0b73523ecee4240b68b77b1',1,'global.h']]],
  ['valor_5fminimo_5famostra',['VALOR_MINIMO_AMOSTRA',['../global_8h.html#aba01c8dc29fca452f9bc28d6e348a6bd',1,'global.h']]]
];
