var searchData=
[
  ['menu_5finicial',['menu_inicial',['../menu_8h.html#a6c9a585362a8abbc44147a4c323905c5',1,'menu.h']]],
  ['menu_5fquant_5fsensores',['menu_quant_sensores',['../quant__sensores_8h.html#afce2136516dfca91ecc1476e02a96a87',1,'quant_sensores.h']]],
  ['menu_5ftempo_5famostra',['menu_tempo_amostra',['../tempo__amostra_8h.html#a32fe6dedb5a0fbb083a4c47cc11f20af',1,'tempo_amostra.h']]],
  ['mq_5fgl_5fr0',['mq_gl_r0',['../mq6_8h.html#ab44754b00d2ed85aa631a1d561352241',1,'mq6.h']]]
];
