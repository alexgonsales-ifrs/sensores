var searchData=
[
  ['gl_5festado',['gl_estado',['../global_8h.html#a4f92392e04f94eb58aac8061da80df88',1,'global.h']]],
  ['gl_5fitem_5fmenu_5fconfig_5famostra',['gl_item_menu_config_amostra',['../estados_8c.html#a720982c93a8b0a09f71e0dbf003b6575',1,'estados.c']]],
  ['gl_5fitem_5fmenu_5fconfig_5fsensores',['gl_item_menu_config_sensores',['../estados_8c.html#a8acad2fa4b57e7234af64f211ffbfe4c',1,'estados.c']]],
  ['gl_5fitem_5fmenu_5fprincipal',['gl_item_menu_principal',['../estados_8c.html#a445032c73f1bfa08997a5c2238c6d3b7',1,'estados.c']]],
  ['gl_5fitem_5fmenu_5fver_5ftodos',['gl_item_menu_ver_todos',['../estados_8c.html#a196c2cbbf463d552ce2fd012b40d61fc',1,'estados.c']]]
];
