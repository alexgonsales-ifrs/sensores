var searchData=
[
  ['i_5fquant_5fsensores',['i_quant_sensores',['../structmenu__sensores.html#ac78833ccf2a23ed35c02345d236d8210',1,'menu_sensores']]]
];
