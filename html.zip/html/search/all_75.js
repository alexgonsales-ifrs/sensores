var searchData=
[
  ['ul_5ftempo_5famostra',['ul_tempo_amostra',['../structmenu__amostra.html#a6772f7ef3cdb49b53ea787ca37b117b8',1,'menu_amostra']]]
];
